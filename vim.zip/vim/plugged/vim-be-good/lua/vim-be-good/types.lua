local difficulty = {
    "noob",
    "easy",
    "medium",
    "hard",
    "nightmare",
    "tpope",
}

local games = {
    "words",
    "ci{",
    "relative",
    "hjkl",
    "whackamole",
    "random",
}

return {
    difficulty = difficulty,
    games = games
}

